package com.magictv.hy300

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 18, 28, 18)
            setBackgroundColor(0xFF10131A.toInt())
        }
        val title = TextView(this).apply {
            text = "MAGIC TV  •  TV EN DIRECTO"
            textSize = 25f; setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        urlInput = EditText(this).apply {
            hint = "Pega aquí el enlace de un canal (M3U8)"
            setSingleLine(true); textSize = 16f
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9AA3B2.toInt())
            setBackgroundColor(0xFF252B36.toInt())
        }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, 58))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val play = Button(this).apply { text = "▶  VER CANAL" }
        val stop = Button(this).apply { text = "■  PARAR" }
        buttons.addView(play, LinearLayout.LayoutParams(0, 58, 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, 58, 1f))
        root.addView(buttons)

        status = TextView(this).apply {
            text = "Introduce un enlace de streaming autorizado."
            textSize = 15f; setTextColor(0xFFB7C0CE.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 42))

        playerView = PlayerView(this).apply {
            useController = true
            setBackgroundColor(0xFF000000.toInt())
        }
        root.addView(playerView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        play.setOnClickListener {
            val url = urlInput.text.toString().trim()
            if (url.startsWith("https://") || url.startsWith("http://")) {
                startStream(url)
            } else status.text = "Escribe una URL válida (http/https)."
        }
        stop.setOnClickListener {
            player?.pause()
            status.text = "Reproducción pausada."
        }
    }

    private fun startStream(url: String) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build()
                playerView.player = player
            }
            player?.setMediaItem(MediaItem.fromUri(url))
            player?.prepare()
            player?.play()
            status.text = "Cargando canal…"
        } catch (e: Exception) {
            status.text = "No se pudo abrir el canal: ${e.localizedMessage ?: "error"}"
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
